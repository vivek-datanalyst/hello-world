package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.expr
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{Row, SparkSession}

import scala.util.Random

object DataFrameMapExample {



  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val rdd = sc.parallelize(Seq(
      ("A", 10, 2.3),
      ("B", 20, 3.4),
      ("C", 40, 1.4),
      ("D", 45, 5.2),
    ))
    // Built-in functions
    // https://spark.apache.org/docs/latest/api/sql/index.html#cardinality
    spark.udf.register("randomC4", () => Random.nextDouble(), DataTypes.DoubleType)
    spark.udf.register("my_prod", (a:Int, b:Double) => a * b, DataTypes.DoubleType)
    spark.udf.register("extract_c1", (row: Row) => row.getString(0), DataTypes.StringType)

    val df = spark.createDataFrame(rdd)
      .toDF("c1", "c2", "c3")
      .withColumn("c4", expr("randomC4()"))
      .withColumn("c5", expr("my_prod(c2, c3)"))
      .withColumn("c6", expr("extract_c1(struct(*))"))

    df.show()


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}