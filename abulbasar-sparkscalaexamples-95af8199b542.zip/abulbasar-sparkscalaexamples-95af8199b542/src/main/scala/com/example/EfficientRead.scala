package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.{SparkSession, functions}

object EfficientRead {

  def main(args: Array[String]): Unit = {

    val inputPath = args(0)
    
    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    /*
    val statement = "select count(1), avg(volume) from stocks where year(date) = 2016 and symbol = 'INTC'"

    val df = spark.read.options(Map(
      "inferSchema"-> "true",
      "header"->"true"
    )).csv(inputPath)
    // Input Read: 122.4 MiB
    */

    /*
    val statement = "select symbol, count(1), avg(volume) from stocks where year(date) = 2016 group by symbol"
    val df = spark.read.load(inputPath)
    // Parquet, snappy input: 10.7 MiB
    */

    /*
    val statement = "select symbol, count(1), avg(volume) from stocks where year = 2016 group by symbol"
    val df = spark.read.load(inputPath)
    // Input read: 501.5 KiB, partitioned by year and stored in parquet with snappy
    */

    // val df = spark.table("stocks_parquet_partitioned_bucket")
    val df = spark.read.load("spark-warehouse/stocks_parquet_partitioned_bucket")
    val statement = "select count(1), avg(volume) from stocks where date = 2016 and symbol = 'INTC'"
    // Input size: 19KB



    df.createOrReplaceTempView("stocks")
    spark.sql(statement).collect().foreach(println)


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}