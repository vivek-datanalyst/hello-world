package com.example.scalalang

import java.text.SimpleDateFormat
import java.time.LocalDate
import scala.io.Source

object ScalaEx {

  private def readInputLines(path:String): Vector[String] = {
    val src = Source.fromFile(path)
    val lines = src.getLines().toVector
    src.close()
    lines
  }

  case class Stock(date: String,
                   open: Double,
                   high: Double,
                   low: Double,
                   close: Double,
                   volume: Double,
                   adjclose: Double,
                   symbol: String)

  private def toStock(line:String):Stock = {
    val parts = line.split(",")
    Stock(
      parts(0),
      parts(1).toDouble,
      parts(2).toDouble,
      parts(3).toDouble,
      parts(4).toDouble,
      parts(5).toDouble,
      parts(6).toDouble,
      parts(7)
    )
  }



  def weekDay(s:String):String = {
    //val dateFormatter = new SimpleDateFormat("yyyy-MM-dd")
    //val date = dateFormatter.parse(s)
    LocalDate.parse(s).getDayOfWeek.name()
  }
  def main(args: Array[String]): Unit = {
    val path = args(0)
    println(s"Input path: $path")
    val lines = readInputLines(path)
    lines.take(10).foreach(println)
    val count = lines.size
    println(s"Number of lines: $count")
    val header = lines(0)
    val data = lines.filter(r => !r.equals(header))
    println(s"Number of data lines ${data.size}")
    val stocks = data.map(toStock)
    val countUniqueStocks = stocks.map(r => r.symbol).distinct.size
    println(f"Count of unique stocks: $countUniqueStocks")
    val countBySymbol = stocks
        .groupBy(r=>r.symbol)
        .mapValues(values => values.size)
        .toVector
        .sortBy(_._2)
        .reverse
        .take(10)
    println("Count by symbol: ")
    countBySymbol.foreach(println)

    println("Avg volume per stock symbol")
    stocks
      .map(r => (r.symbol, r.volume))
      .groupBy(_._1)
      .mapValues(values => values.map(_._2).sum/values.size)
      .toVector
      .sortBy(_._2)
      .reverse
      .take(10)
      .foreach(println)

    println("Count of records by day of the week")
    stocks.groupBy(r => weekDay(r.date)).mapValues(_.size)
      .foreach(println)

    println("Top 3 stocks with highest intra-day return in 2016")
    val intraDayReturn = (r:Stock) => (r.close-r.open)/r.open
    stocks.filter(r => r.date.startsWith("2016"))
      .sortBy(intraDayReturn)
      .reverse
      .take(3)
      .foreach(println)


    println("Which stock has seen highest decline in total market cap  in between Jan/01/2016 and Dec/31/2016")
    val marketCapChange = (r:Stock) => r.adjclose * r.volume
    stocks.filter(r => r.date > "2016-01-01" && r.date < "2016-12-31")
      .map(r => (r, marketCapChange(r)))
      .sortBy(_._2)
      .take(3)

      .foreach(println)

  }
}
