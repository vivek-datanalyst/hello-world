package com.example.scalalang

import java.util.Date
import scala.util.control.Breaks._

object HelloWorld {


  def main(args: Array[String]): Unit = {
    println("Hello world!")
    val l1 = Array(1, 2, 3);
    for(v <- l1){
      println(v);
    }
    val mutableArray = scala.collection.mutable.ArrayBuffer[Int](1, 2, 3);
    for(v<-mutableArray){
      println(v)
    }
    val m = Map("a"->1, "b"->2, "c"->3);
    for (v <- m) {
      println(v);
    }
    println("\n\n-------------------MutableMap----------------")
    val mutableM = scala.collection.mutable.Map[String, Int]("a"->100);
    mutableM("a") = 1
    mutableM("b") = 2
    mutableM("c") = 3
    mutableM += ("e"->100)
    mutableM ++= List("e"->100, "g"->200)
    mutableM.remove("c")
    mutableM -= "g"
    mutableM.put("h", 250)
    mutableM.retain((k, v)=>k == "h")
    mutableM.clear()
    for(v<-mutableM){
      println(v)
    }

    val alphabets = List("A", "B", "C", "D", "E")
    val rl = alphabets.reduceLeft(_ + _)
    println(s"RL: ${rl}")

    val rr = alphabets.reduceRight(_ + _)
    println(s"RR: ${rr}")

    val fl = alphabets.foldLeft("$")(_ + _)
    println(s"FL: ${fl}")

    val fr = alphabets.foldRight("$")(_+_)
    println(s"FR: ${fr}")

    val sl = alphabets.scanLeft("$")(_ + _)
    println(s"SL: ${sl}")

    val sr = alphabets.scanRight("$")(_ + _)
    println(s"SR: ${sr}")

    val l = Array(1.0, 2.0, 3.0, -4.0, "5.0")
    val roots = l.collect {
      case i: Double if i > 0 => (i, math.sqrt(i))
    }
    roots.foreach(println)

    println("------------- BREAK --------------")
    breakable {
      (0 until 10).foreach { e =>
        if (e > 5) {
          break
        }
        println(e)
      }
    }

    println("------------- Case class ----------------")

    case class Person(name: String, age: Int)
    val p = Person("Martin Odersky", 58)

    p match {
      case Person(name, _) => println(s"Name: $name")
      case p: Person => println(s"Person(${p.name})")
      case _ => print("Not Person Type")
    }

    // scala loops
    println("------------- RANGE -----------------")
    for(v<-0 until 10){
      println(v)
    }

    println("------------- Vector updated -----------------")
    val v = Vector(3, 6, 1)
    v.updated(0, 100).foreach(println)


    println("------------- Sorting -----------------")
    case class Employee(name:String, age:Int);
    val employees = Seq(Employee("Elon", 52), Employee("Bill", 72))

    employees.sortBy(e => e.name).foreach(println)

    employees.sortWith((e1, e2) => e1.name<e2.name).foreach(println)

    employees.sortBy(e => e.name).reverse.foreach(println)

    case class EmployeeSortable(name: String, age: Int) extends Ordered[EmployeeSortable] {
      override def compare(that: EmployeeSortable): Int = name.compareTo(that.name)
    }

    val sortableEmployees = Seq(EmployeeSortable("Elon", 52), EmployeeSortable("Bill", 72))

    sortableEmployees.sorted.foreach(println);



  }




}