package com.example.scalalang
import java.text.SimpleDateFormat
import scala.collection.mutable.ArrayBuffer
object DemoApp {

  def main(args: Array[String]): Unit = {
    println("Hello world")
    var x = 20.234
    x = 10
    val y = 10

    val c = Seq(1, 2, 3)
    // c.update(0, 10)
    c.foreach(println)

    val c2 = scala.collection.mutable.ArrayBuffer[Int]()
    c2.append(10)
    c2.append(20)
    c2.foreach(println)

    var c3 = scala.collection.mutable.ArrayBuffer[Int]()
    c3.append(10)
    c3.append(20)
    c3.foreach(println)

    var c4 = Seq(1, 2, 3)
    c4.foreach(println)

    c4 = Seq(5, 6, 7)
    c4.foreach(println)

    c4 = Vector(5, 6, 7)
    c4.foreach(println)

    val height = 1.9f
    val name = "James"
    val salary : Long = 100000
    println(f"$name%s is $height%2.4f meters tall") // James is 1.90 meters tall


    val simpleDateFormatter = new SimpleDateFormat("yyyy-MM-dd")
    val date = simpleDateFormatter.parse("2018-07-10")
    println(f"Date: $date")

    var x2 : Option[Int] = None

    x2 = Some(1000)

    if(x2.isDefined){
      println(f"Value of x2: ${x2.get}")
    }

    var i =10
    lazy val j = i + 20
    i = 100
    println(f"Value of j: ${j}")
    i = 1000
    println(f"Value of j: ${j}")

    i = 10
    def k = i + 20
    println(f"value of k: ${k}")
    i = 100
    println(f"value of k: ${k}")
    i = 1000
    println(f"value of k: ${k}")

    val x20 = Seq(1, 4, 5, 6, 10)
    for(v <- x20){
      println(f"v=> ${v}")
    }
    for(v <- (0 to 10)){
      println(f"v=> ${v}")
    }

    val l1 = Array(1, 2, 3)
    val l2 = Array("one", "two", "three")
    for (v1 <- l1; v2 <- l2) println(v1, v2)
    // Below expression is equivalent to the line above
    for(v1<-l1){
      for(v2<-l2){
        println(v1, v2)
      }
    }

    for(v<-l1.zip(l2)){
      println(f"Zipped: ${v}")
    }
    println("------------- For expression ---------------")
    val x12 = Seq(1, 2, 3)
    val x13 = for(v<-x12) yield v + 10
    x13.foreach(println)
    println("----------------- function call ------------------")
    val x14 = sum(10, 20)
    println(f"X14: $x14")

    def max = (i:Int, j:Int) => if(i > j) i else j
    println(f"Max of (30, 40): ${max(30, 40)}")


    println("-------Anonymous Function--------------")
    val series = Array(3, 6, 7, 10)
    val x15= series.reduce((i: Int, j: Int) => i + j)
    println(s"X15: $x15")

    val x16 = (message: String, level: String) => println(s"$level: $message")
    log("debug message 1")
    log("debug message 2", "WARN")

    log("debug message 3", level = "WARN")

    log(level = "WARN", message =  "debug message 4" )

    x16("debug message 5", "INFO")

    println("------------------- Exception ---------------")

    val l = Array(0, 2, 4, "Six")

    try {
      l.map(_ match {
        case i: Int => i * 2
        case _ => throw new RuntimeException("break exception")
      })
    } catch {
      case e: RuntimeException => println(s"Exception handled ${e.getMessage}")
      case _ => println("Unknown exception has occurred")
      // Catches everything including OutOfMemoryError
    }finally {
      println("Finally statement executed")
    }

    println("------------------ Break statement ----------------------")
    import scala.util.control.Breaks._
    breakable {
      (0 until 10).foreach { e =>
        if (e > 5) {
          break
        }
        println(e)
      }
    }

    println("----------------------Implicit conversion----------------------")

    implicit def double2Int(d:Double) = d.toInt
    // val x24 : Int= double2Int(2.3)
    val x24 : Int = 2.3

    println("----------------------- implicit conversion using class-------------")
    implicit class GeneratorInt(i: Int) {
      def -->(j: Int) = i to j
    }

    val x25 = 2 --> 100
    println("-------------- Range --------------")
    for(v <- (0 to 5)){
      println(f"to v -> $v")
    }
    for (v <- (0 until 5)) {
      println(f"until v -> $v")
    }

    println("-------------- List type conversion --------------")
    val x26 = new ArrayBuffer[Int]()
    x26.append(12)
    x26 += 20
    x26 ++= Seq(30, 46)
    x26.remove(0)
    val x27 = x26.toVector
    x27.foreach(println)

  }

  def log(message: String, level: String = "INFO"): Unit = {
    println(s"$level: $message")
  }

  def sum(i:Int, j :Int) = {
    i + j
  }


}
