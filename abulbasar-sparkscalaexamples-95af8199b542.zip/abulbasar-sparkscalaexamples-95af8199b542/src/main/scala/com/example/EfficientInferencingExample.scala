package com.example

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object EfficientInferencingExample {

  def listFiles(path:String, configuration: Configuration) = {
    val fs = FileSystem.get(configuration)
    val files = fs.listStatus(new Path(path))
    files.map(r=>r.getPath.toUri.getPath)
  }

  def main(args: Array[String]): Unit = {

    val inputPath = args(0)
    
    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val startTime = System.currentTimeMillis()

    val files = listFiles(inputPath, sc.hadoopConfiguration)

    val sampleFile = files(0)

    println(f"Sample file: $sampleFile")

    val dfSample = spark.read.options(Map(
      "samplingRatio"->"0.01"
    )).json(sampleFile)
    dfSample.printSchema()

    val df = spark.read.schema(dfSample.schema).json(inputPath)

    val count = df.count()

    println(f"Count of records: $count")
    val duration = System.currentTimeMillis() - startTime
    println(f"Total time taken: $duration")
    // 54 -> 22 -> 19
    // df.show()

    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}