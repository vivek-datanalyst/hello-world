package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.expressions.Window
import scala.util.Random

object AnalyticalQueriesExample {



  def main(args: Array[String]): Unit = {

    val inputPath = args(0)
    
    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val df = spark.read.option("inferSchema", "true").option("header", "true").csv(inputPath)

    df.show()

    println("-------- Count by symbol --------")
    df.groupBy("symbol").count().show()

    println("-------- Min, max volume by symbol --------")
    df.groupBy("symbol")
      .agg(
        min(df.col("volume")),
        min(df.col("volume"))
      ).show()

    println("-------- Min, max volume by symbol and year --------")
    df
      .withColumn("year", expr("year(date)"))
      .groupBy("symbol", "year")
      .agg(
        min(df.col("volume")),
        min(df.col("volume"))
      ).show()

    println("-------- Roll up volume and adjclose by symbol and year --------")
    df
      .withColumn("year", expr("year(date)"))
      .rollup("symbol", "year")
      .agg(
        sum("volume"),
        min("adjclose"),
        max("adjclose")
      )
      .orderBy(asc("symbol"), desc("year"))
      .show()


    println("-------- Cube volume and adjclose by symbol and year --------")
    df
      .withColumn("year", expr("year(date)"))
      .cube("symbol", "year")
      .agg(
        sum("volume"),
        min("adjclose"),
        max("adjclose")
      )
      .orderBy(asc("symbol"), desc("year"))
      .show(30, false)


    println("-------- Find top 3 best performing stocks by intra-day gain for each year --------")

    df
      .selectExpr("*", "(open-close)/open as pct")
      .withColumn("rank", row_number().over(
              Window.partitionBy("symbol").orderBy(desc("pct"))))
      .where("rank <= 3")
      .show()


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}