package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession, functions => F}

object DataFrameExample {

  def main(args: Array[String]): Unit = {

    val path = args(0)

    println(s">>>>>>>>>>>Input path: $path")


    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val df: DataFrame = spark.read.format("csv")
      .options(Map("header"-> "true", "inferSchema"->"true"))
      .load(path)

    df.show()

    df.printSchema()
    println("========== Show existing tables =============")
    spark.sql("show tables").show()

    println("========== Show tables after registering stocks table =============")

    df.createOrReplaceTempView("stocks")
    spark.sql("show tables").show()

    spark
      .sql("select symbol, count(1), avg(volume) from stocks group by symbol")
      .show()

    println("=================== Dataframe DSL output =======================")
    val output = df.filter("year(date) = 2016")
      .withColumn("pct", F.expr("(close-open)/open"))
      .groupBy("symbol")
      .agg(F.count("symbol").as("count")
        , F.avg("volume").as("avg_volume")
        , F.avg("pct").as("avg_pct")
      )
      .withColumnRenamed("symbol", "Symbol")
      .orderBy(F.desc("avg_pct"))
      .filter("avg_pct>.01")
      .limit(5)

    output.show()

    df.withColumn("pct", F.expr("(close-open)/open"))
      .selectExpr("min(pct)", "max(pct)")
      .show()

    output.write.format("json").mode("overwrite")
      .save("/tmp/stocks_agg")

    println("Waiting for user input for termination")
    System.in.read()
  }
}