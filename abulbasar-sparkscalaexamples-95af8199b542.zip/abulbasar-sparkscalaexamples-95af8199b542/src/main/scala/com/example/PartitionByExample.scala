package com.example

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.{Partitioner, SparkConf, SparkContext, TaskContext}


object PartitionByExample {

  case class Stock(date: String,
                   open: Double,
                   high: Double,
                   low: Double,
                   close: Double,
                   volume: Double,
                   adjclose: Double,
                   symbol: String)

  private def toStock(line: String): Stock = {
    val parts = line.split(",")
    Stock(
      parts(0),
      parts(1).toDouble,
      parts(2).toDouble,
      parts(3).toDouble,
      parts(4).toDouble,
      parts(5).toDouble,
      parts(6).toDouble,
      parts(7)
    )
  }

  def deleteOutputDirectory(path:String, hadoopConfig: Configuration): Unit = {
    val hdfs = FileSystem.get(hadoopConfig)
    val p = new Path(path)
    if(hdfs.exists(p)){
      hdfs.delete(new Path(path), true)
    }
  }

  def main(args: Array[String]): Unit = {

    val path = args(0)
    val outputPath = args(1)
    println(s">>>>>>>>>>>Input path: $path, Output path: $outputPath")

    // https://spark.apache.org/docs/latest/configuration.html
    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local")
      // .setIfMissing("spark.hadoop.validateOutputSpecs", "false")

    val sc = new SparkContext(conf) // Start of a session
    sc.setLogLevel("WARN")
    val hadoopConfig = sc.hadoopConfiguration
    deleteOutputDirectory(outputPath, hadoopConfig)
    println(s"Spark Web UI: ${sc.uiWebUrl.get}")
    val rdd = sc.textFile(path) // BaseRDD

    println(f"Num of base rdd partitions: ${rdd.partitions.size}")

    rdd.take(10).foreach(println) //Action. Creates a job
    val header = rdd.first() //Action. Creates a job
    val output = rdd
      .filter(r => !r.equals(header)) // Narrow
      .map(toStock)
      .map(r => (r.symbol, r))
      .partitionBy(new Partitioner {
        override def numPartitions: Int = 4
        override def getPartition(key: Any): Int = key.hashCode() % numPartitions
      })
      .map(_._2)
      .mapPartitions(partition => {
        val ctx = TaskContext.get()
        val vec = partition.toVector
        val sortedVec = vec.sortBy(r=>r.symbol)
        sortedVec.toIterator
      })

    output.saveAsTextFile(outputPath)

    println("Waiting for user input for termination")
    System.in.read()
  }
}