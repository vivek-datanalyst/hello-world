package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import java.nio.file.Paths
import scala.util.Random

object AQEExamples {

  private val numCustomers = 200
  private val numProducts = 1000
  private val numOrders = numProducts * 10000
  private val numProductFamily = 500

  case class Product(id:String, name:String, unitPrice:Double, category: String)
  case class Order(customerId:String, productId: String, units: Int, price: Double, ts:Long)

  private val alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

  private def randStr(n: Int) = (1 to n).map(_ => alpha(Random.nextInt(alpha.length))).mkString
  private def createProducts(n:Int): Seq[Product] = {
    (0 until n).map(i => {
      val id = s"product-${i % 6d}"
      val name = randStr(24)
      val unitPrice = Random.nextDouble() * 100
      val catId = if(Random.nextDouble() < 0.2) 0 else Random.nextInt(numProductFamily)
      val category = s"Cat${catId%6d}"
      Product(id, name, unitPrice, category)
    })
  }

  private def createOrders(m:Int, productCount: Int): Seq[Order] = {
    (0 until m).map(i => {
      val customerId = "C" + Random.nextInt(numCustomers)
      val productId = Random.nextInt(productCount)
      val units = Random.nextInt(10)
      val price = Random.nextDouble() * 120
      val ts = System.currentTimeMillis() - Random.nextInt(3600000 * 200)
      Order(customerId, s"product-${productId % 6d}", units, price, ts)
    })
  }

  def main(args: Array[String]): Unit = {

    val outputPath = "/tmp/output"
    val df1Path = Paths.get(outputPath).resolve("df1").toString
    val df2Path = Paths.get(outputPath).resolve("df2").toString
    val finalOutput = Paths.get(outputPath).resolve("output").toString


    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")
//      .setIfMissing("spark.default.parallelism", "10") // RDD
      .set("spark.sql.autoBroadcastJoinThreshold", "-1") // "-1" 10485760 to disable
      .set("spark.sql.shuffle.partitions", "200") // Dataframe
      .set("spark.sql.adaptive.enabled", "true") // Default: true
      .set("spark.sql.adaptive.advisoryPartitionSizeInBytes", "10485760") // Default: 50 MB
      .set("spark.sql.adaptive.coalescePartitions.enabled", "false")
      .set("spark.sql.adaptive.skewJoin.enabled", "false")
      .set("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "2")
      // If a partition 3x size of the median partition size, then
      // spark will attempt to break the partition using a "salt"
      .set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "100K") // Default: 256MB


    val spark = SparkSession.builder().config(conf).getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val sc = spark.sparkContext
    println(s"WebUI: ${sc.uiWebUrl}")

    val writeOutput = (df:DataFrame)=>{
      println(s"Writing output to $outputPath")
      df.write.mode(SaveMode.Overwrite).save(finalOutput)
    }

    import spark.implicits._

    val execDataPrep = false
    if(execDataPrep) {
      println("Preparing data. You can comment this part of the code after preparing the data")


      val df1 = sc.parallelize(createOrders(numOrders, numProducts)).toDF()
      val df2 = sc.parallelize(createProducts(numProducts)).toDF()

      df1.write.mode(SaveMode.Overwrite).save(df1Path)
      df2.write.mode(SaveMode.Overwrite).save(df2Path)

      println("Write is complete")
    }else{

      val df1 = spark.read.load(df1Path)
      val df2 = spark.read.load(df2Path)

      val output = df1
        .join(df2, df1.col("productId") === df2.col("id"))
        .groupBy(df2.col("category"))
        .agg(avg("price"), count("price"))


      println("Explain plan")
      output.explain()

      println(f"Output partitions: ${output.rdd.partitions.length}")

      writeOutput(output)
    }



    println("Waiting for user input for termination")
    System.in.read()
  }
}