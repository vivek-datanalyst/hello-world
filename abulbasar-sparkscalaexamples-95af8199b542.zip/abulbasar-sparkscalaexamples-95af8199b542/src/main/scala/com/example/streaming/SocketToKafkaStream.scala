package com.example.streaming

import org.apache.spark.SparkConf
import org.apache.spark.sql.streaming.OutputMode
import org.apache.spark.sql.{Dataset, SparkSession}

object SocketToKafkaStream {



  def main(args: Array[String]): Unit = {

    val kafkaHost = "einext06"
    val kafkaPort = 9092
    val topic = "demo"

    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")
      .setIfMissing("spark.sql.adaptive.enabled", "false")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    import spark.implicits._

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")
    println("Before starting spark make sure socket server is running " +
      "$ nc -nlk 9999")

    val lines: Dataset[String] = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9999)
      .load
      .as[String]

//    val words = lines.flatMap(_.split("\\W+"))
//    words.printSchema
//
//    val counter = words.groupBy("value").count

//    counter.writeStream
//      .outputMode(OutputMode.Complete())
//      .format("console")
//      .start

    lines.writeStream
      .outputMode(OutputMode.Append())
      .format("kafka")
      .option("kafka.bootstrap.servers", s"$kafkaHost:$kafkaPort")
      .option("topic", topic)
      .option("checkpointLocation", "/tmp/sparkCheckpoint")
      .start()

    spark.streams.awaitAnyTermination()


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}