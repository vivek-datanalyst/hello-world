package com.example.streaming

import org.apache.spark.SparkConf
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.streaming.{OutputMode, Trigger}

object KafkaToKafka {



  def main(args: Array[String]): Unit = {

    val kafkaHost = "einext06"
    val kafkaPort = 9092
    val sourceTopic = "demo"
    val targetTopic = "demo2"

    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")
      .setIfMissing("spark.sql.adaptive.enabled", "false")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")


    val lines = spark.readStream
      .format("kafka")
      .options(Map(
        "kafka.bootstrap.servers" -> s"$kafkaHost:$kafkaPort",
        "startingOffsets" -> "earliest",
        "failOnDataLoss" -> "true",
        "maxOffsetsPerTrigger" -> "100",
        "includeHeaders" -> "false",
        "subscribe" -> sourceTopic
      ))
      .load()
      .withColumn("key", functions.expr("cast(key as string)"))
      .withColumn("value", functions.expr("cast(value as string)"))

    lines.printSchema()

    lines.writeStream
        .outputMode(OutputMode.Append())
        .format("console")
        .start

    lines
      .selectExpr("key", "upper(value) as value")
      .writeStream
      .format("kafka")
      .outputMode("append")
      .option("checkpointLocation", "/tmp/sparkCheckpoint")
      .option("topic", targetTopic)
      .option("kafka.bootstrap.servers", s"$kafkaHost:$kafkaPort")
      .start()

    spark.streams.awaitAnyTermination()


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}