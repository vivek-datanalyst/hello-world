package com.example.streaming

import org.apache.spark.SparkConf
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.streaming.{OutputMode, Trigger}

object FileToKafka {



  def main(args: Array[String]): Unit = {

    val kafkaHost = "einext06"
    val kafkaPort = 9092
    val topic = "demo"
    val inputPath = "/data/stocks.small.csv"

    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")
      .setIfMissing("spark.sql.adaptive.enabled", "false")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val df = spark.read.options(Map(
      "header"-> "true",
      "inferSchema"-> "true"
    )).csv(inputPath)


    val output = df
      .withColumn("date", functions.expr("cast(date as date)"))
      .selectExpr("to_json(struct(*)) as value")

    output.show(10, false)

    output.write
      .format("kafka")
      .options(Map(
        "kafka.bootstrap.servers" -> s"$kafkaHost:$kafkaPort",
        "topic" -> topic
      )).save()


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}