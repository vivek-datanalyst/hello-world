package com.example

import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, Row, RowFactory, SparkSession, functions => F}

object Rdd2DataFrameExample {

  case class Person(name:String, age: Int)

  def buildModel(people: Dataset[Person]): Unit = {

  }

  def buildModelDf(people: DataFrame): Unit = {

  }

  def main(args: Array[String]): Unit = {



    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    import spark.implicits._

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val rdd = sc.parallelize(Seq(
      ("A", 1),
      ("B", 2),
      ("C", 3),
      ("D", 4),
    ))

    rdd.collect().foreach(println)

    val df = spark.createDataFrame(rdd).toDF("c1", "c2")
    df.show()

    val peopleDs:Dataset[Person] = sc.parallelize(Seq(
      Person("Elon", 52),
      Person("Bill", 72)
    )).toDS()
    peopleDs.show()

    val peopleDf: DataFrame = sc.parallelize(Seq(
      Person("Elon", 52),
      Person("Bill", 72)
    )).toDF()

    peopleDf.show()

    val person1:Person = peopleDs.take(1)(0)
    val person2:Row = peopleDf.take(1)(0)

    println(s"Type of person dataset: ${person1.getClass.getName}")

    println(s"Type of person dataframe: ${person2.getClass.getName}")

    // buildModel only accept dataset of Person type.
    // hence give strong type checking during compile time
    buildModel(peopleDs)

    // Since buildModelDf takes a dataframe, we can pass any arbitrary
    // dataframe. You need to put input validation logic to check
    // whether the user has passed the correct datatype type
    buildModelDf(peopleDf)
    buildModelDf(spark.range(10).toDF())

    peopleDs.map(r => r.name).collect().foreach(println)

    val rdd2 = sc.parallelize(Seq(
      Row("Elon", 52),
      Row("Bill", 72),
    ))

    println("============= Creating dataframe from RDD using schema ===============")
    val schema = StructType(Seq(
      StructField("name", DataTypes.StringType),
      StructField("age", DataTypes.IntegerType)
    ))
    val df3 = spark.createDataFrame(rdd2, schema)
    df3.show()

    val row = df3.first()
    val index = df3.schema.fieldIndex("name")
    val name = row.getString(index)
    println(s"Name: $name")

    val nameDf = peopleDf.mapPartitions(iter =>
      iter.toVector.map(_.getString(index)).toIterator
    )
    nameDf.show()


    val ageDf = peopleDf.mapPartitions(iter =>
      iter.toVector.map(_.getInt(1).toDouble).toIterator
    )
    val ageRdd: RDD[Double] = ageDf.rdd

    val stats = ageRdd.stats()
    println(s"Min: ${stats.min}, Max: ${stats.max}, Std: ${stats.stdev}")


    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}