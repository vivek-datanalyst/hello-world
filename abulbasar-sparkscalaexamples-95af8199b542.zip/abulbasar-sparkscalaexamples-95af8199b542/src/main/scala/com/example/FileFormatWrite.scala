package com.example

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.compress.{GzipCodec}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}

object FileFormatWrite {

  def main(args: Array[String]): Unit = {

    val inputPath = args(0)
    
    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val df = spark.read.options(Map(
      "inferSchema"-> "true",
      "header"->"true"
    )).csv(inputPath)

    df.show()


    df.write.format("csv").options(Map(
      "header"-> "true",
      "compression"->classOf[GzipCodec].getName
    )).mode(SaveMode.Overwrite).save("/tmp/stocks_csv_gz")

    df.write.format("json").save("/tmp/stocks_json")

    df.write.format("json").options(Map(
      "compression" -> classOf[GzipCodec].getName
    )).mode(SaveMode.Overwrite).save("/tmp/stocks_json_gz")

    df.write.format("parquet").options(Map(
      "compression" -> "snappy"
    )).mode(SaveMode.Overwrite).save("/tmp/stocks_parquet_snappy")

    df.write.format("orc").options(Map(
      "compression" -> "snappy"
    )).mode(SaveMode.Overwrite).save("/tmp/stocks_orc_snappy")

    /*
    47M     /tmp/stocks_csv_gz
    282M    /tmp/stocks_json
    57M     /tmp/stocks_json_gz
    59M     /tmp/stocks_orc_snappy
    44M     /tmp/stocks_parquet_snappy
     */
    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}