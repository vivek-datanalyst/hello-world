package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{SaveMode, SparkSession, functions}

object PartitionWrite {

  def main(args: Array[String]): Unit = {

    val inputPath = args(0)
    
    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")

    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    sc.setLogLevel("WARN")

    println(s"Spark Web UI: ${sc.uiWebUrl}")

    val df = spark.read.options(Map(
      "inferSchema"-> "true",
      "header"->"true"
    )).csv(inputPath)

    df.show()
    println("------------ Write data with partitions -------------------")
    df.withColumn("year", functions.expr("year(date)"))
      .write
      .partitionBy("year")
      .mode("overwrite")
      .save("/tmp/stocks_parquet_partitioned")
      // Size: 47M

    val bucketCount = 4
    println("------------ Write data with partitions and bucket and sort the buckets -------------------")
    df.withColumn("year", functions.expr("year(date)"))
      .repartition(bucketCount, col("symbol"))
      .write
      .partitionBy("year")
      .bucketBy(bucketCount, "symbol")
      .sortBy("symbol")
      .mode("overwrite")
      .saveAsTable("stocks_parquet_partitioned_bucket")

    println("\n\nWaiting for user input for termination")
    System.in.read()
  }
}