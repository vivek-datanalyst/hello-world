package com.example

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}


object CachingExample {

  case class Stock(date: String,
                   open: Double,
                   high: Double,
                   low: Double,
                   close: Double,
                   volume: Double,
                   adjclose: Double,
                   symbol: String)

  private def toStock(line: String): Stock = {
    val parts = line.split(",")
    Stock(
      parts(0),
      parts(1).toDouble,
      parts(2).toDouble,
      parts(3).toDouble,
      parts(4).toDouble,
      parts(5).toDouble,
      parts(6).toDouble,
      parts(7)
    )
  }

  def deleteOutputDirectory(path:String, hadoopConfig: Configuration): Unit = {
    val hdfs = FileSystem.get(hadoopConfig)
    val p = new Path(path)
    if(hdfs.exists(p)){
      hdfs.delete(new Path(path), true)
    }
  }

  def main(args: Array[String]): Unit = {

    val path = args(0)

    println(s">>>>>>>>>>>Input path: $path")


    val conf = new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local")

    val sc = new SparkContext(conf) // Start of a session
    sc.setLogLevel("WARN")

    sc.applicationId

    println(s"Spark Web UI: ${sc.uiWebUrl.get}")
    val rdd = sc.textFile(path) // BaseRDD

    println(f"Num of base rdd partitions: ${rdd.partitions.size}")


    val header = rdd.first() //Action. Creates a job
    val output = rdd
          .filter(r => !r.equals(header)) // Narrow
          .map(toStock)
    // output.cache() // 318MN
    // output.persist(StorageLevel.MEMORY_ONLY_SER) // 131MB
    // output.persist(StorageLevel.DISK_ONLY) // 131MB
    // output.persist(StorageLevel.OFF_HEAP)
    output.count()
    output.unpersist()

    println("Waiting for user input for termination")
    System.in.read()
  }
}