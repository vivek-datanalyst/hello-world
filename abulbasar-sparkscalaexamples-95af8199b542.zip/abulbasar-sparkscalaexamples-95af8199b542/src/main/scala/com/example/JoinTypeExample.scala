package com.example

import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.util.Random

object JoinTypeExample {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder().config(new SparkConf()
      .setAppName(getClass.getName)
      .setIfMissing("spark.master", "local[*]")
      .setIfMissing("spark.default.parallelism", "10")
      .set("spark.sql.autoBroadcastJoinThreshold", "-1")
      .set("spark.sql.shuffle.partitions", "32")
      .set("spark.sql.adaptive.enabled", "true")
    ).getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")
    val sc = spark.sparkContext

    import spark.implicits._

    val df1 = sc.parallelize(Seq(("A", 1), ("B", 2), ("C", 3))).toDF("letter", "value")
    val df2 = sc.parallelize(Seq(("A", 4), ("B", 5))).toDF("letter", "value")


    println("Waiting for user input for termination")
    System.in.read()
  }
}